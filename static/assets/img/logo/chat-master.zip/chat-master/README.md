[![Build Status](https://travis-ci.org/kigsmtua/chat.svg?branch=master)](https://travis-ci.org/kigsmtua/chat)

# Chat
Live video,chat,audio messaging system borrowing inspirations from facebook messenger

Demo application found at https://live-chat-clone.herokuapp.com

# project Technologies
1. Django 1.11.3
2. Django rest framework
3. Django channels
4. Angular 4
5. Ionic 2

# Running The project
# Using Docker
1. Clone this repository
2. Install Docker
3. Run docker-compose up --build to build and pull the containers (will take awhile)
4. On a separate terminal, you can run commands as follows : docker exec -it app bash -c <command>
